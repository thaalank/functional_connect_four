let hours_worked = [12; 12; 12]
